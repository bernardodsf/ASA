from flask import Flask, render_template, flash, redirect, url_for, request
from flask_bootstrap import Bootstrap
from clienteForm import ClienteForm, ClienteForm2, ClienteForm3
from dbUtils import DbUtils

app = Flask(__name__)
app.config['SECRET_KEY'] = 'minha palavra secreta'
Bootstrap(app)

@app.route('/')
def homepage():
    title = "Arquitetura de Software Aplicada!!"
    paragraph = "Esta é a primeira página com renderização!!"
    message = "Funcionou!!!"

    try:
        return render_template("index.html", title = title, paragraph = paragraph, message = message)
    except Exception as e:
        return str(e)

@app.route('/disciplina')
def show_disciplina():
    username = "Joao"
    lista_disc = ['IEC', 'CALC2', 'ASA', 'BD']
    dict_disc = {'IEC':45, 'CALC2':45, 'ASA':60, 'BD':60}
    return render_template('disciplinas.html', username = username, lista_disc = lista_disc, dict_disc = dict_disc)

@app.route('/seila')
def show_seila():
    try:
        return render_template("index2.html")
    except Exception as e:
        return str(e)

@app.route('/usuario', methods=['GET', 'POST'])
def index():
    form = ClienteForm()
    if form.validate_on_submit():
        usuario = form.usuario.data
        email = form.email.data
        senha = form.senha.data
        dbUtils = DbUtils()
        if(dbUtils.novoCadastro(usuario, email, senha)):
            return redirect(url_for('pessoais', email = email, usuario = usuario))
        else:
            flash('Essas informações já foram utilizadas')
    return render_template('index.html', form = form)

@app.route('/usuario/pessoais', methods=['GET', 'POST'])
def pessoais():
    email = request.args['email']
    usuario = request.args['usuario']
    form = ClienteForm2()
    if form.validate_on_submit():
        nome = form.nome.data
        sobrenome = form.sobrenome.data
        aniversario = form.aniversario.data
        sexo = form.sexo.data
        dbUtils = DbUtils()
        if(dbUtils.novoUsuario(email, nome, sobrenome, aniversario, sexo)):
            return redirect(url_for('endereco', email = email, usuario = usuario))
        else:
            flash('Faltam informações ou alguma informação está incorreta')
    return render_template('index2.html', form = form, usuario = usuario)

@app.route('/usuario/endereco', methods=['GET', 'POST'])
def endereco():
    email = request.args['email']
    usuario = request.args['usuario']
    form = ClienteForm3()
    if form.validate_on_submit():
        endereco = form.endereco.data
        numero = form.numero.data
        complemento = form.complemento.data
        bairro = form.bairro.data
        cidade = form.cidade.data
        estado = form.estado.data
        dbUtils = DbUtils()
        if(dbUtils.novoEndereco(email, endereco, numero, complemento, bairro, cidade, estado)):
            return redirect(url_for('index'))
        else:
            flash('Faltam informações ou alguma informação está incorreta')
    return render_template('index3.html', form = form, usuario = usuario)

if __name__ == "__main__":
    app.run(debug = True, host='0.0.0.0', port=8080)