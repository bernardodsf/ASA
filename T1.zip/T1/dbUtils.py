from sqlalchemy import create_engine

class DbUtils:
    db_string = "postgresql+psycopg2://postgres:banco@192.168.99.100:5432/postgres"
    db_query = " "

    def novoCadastro(self, usuario, email, senha):
        db = create_engine(self.db_string)
        try:
            db.execute("INSERT INTO tb_cadastro(usuario, email, senha) VALUES (%s, %s, %s)", usuario, email, senha)
            return True
        except:
            return False

    def novoUsuario(self, email, nome, sobrenome, aniversario, sexo):
        db = create_engine(self.db_string)
        try:
            db.execute("INSERT INTO tb_pessoais(email, nome, sobrenome, aniversario, sexo) VALUES (%s, %s, %s, %s, %s)", email, nome, sobrenome, aniversario, sexo)
            return True
        except:
            return False
    
    def novoEndereco(self, email, endereco, numero, complemento, bairro, cidade, estado):
        db = create_engine(self.db_string)
        try:
            db.execute("INSERT INTO tb_endereco(email, endereco, numero, complemento, bairro, cidade, estado) VALUES (%s, %s, %s, %s, %s, %s, %s)", email, endereco, numero, complemento, bairro, cidade, estado)
            return True
        except:
            return False

