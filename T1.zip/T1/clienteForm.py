from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, IntegerField, PasswordField, RadioField, validators
from wtforms.validators import Required
from wtforms.fields.html5 import DateField, EmailField

class ClienteForm(FlaskForm):

    usuario = StringField('Usuario', validators=[Required()])
    email = EmailField('Endereço de email', validators=[Required()])
    senha = PasswordField('Senha', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='As senhas devem ser iguais')
    ])
    confirm = PasswordField('Confirme a senha')
    submit = SubmitField('Próximo')

class ClienteForm2(FlaskForm):

    nome = StringField('Nome', validators=[Required()])
    sobrenome = StringField('Sobrenome', validators=[Required()])
    aniversario = DateField('Data de aniversário', validators=[Required()], format='%Y-%m-%d')
    sexo = RadioField('Sexo', validators=[Required()], choices=[('Masculino','Masculino'), ('Feminino','Feminino')])
    submit = SubmitField('Próximo')

class ClienteForm3(FlaskForm):
    endereco = StringField('Endereço', validators=[Required()])
    numero = IntegerField('Número', validators=[Required()])
    complemento = StringField('Complemento', validators=None)
    bairro = StringField('Bairro', validators=[Required()])
    cidade = StringField('Cidade', validators=[Required()])
    estado = StringField('Estado', validators=[Required()])
    submit = SubmitField('Finalizar')
